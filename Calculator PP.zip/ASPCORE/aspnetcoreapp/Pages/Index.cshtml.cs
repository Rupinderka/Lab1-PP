using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace aspnetcoreapp.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        // Properties to store the results (public so they can be accessed in the Razor page)
        public double? SquareResult { get; set; }
        public double? CubeResult { get; set; }
        public double? Summation { get; set; }

        public void OnGet()
        {
        }

        public void OnPost()
        {
            // Define the function to apply exponentiation
            double Exponentiation(int exponent, double value)
            {
                return Math.Pow(value, exponent);
            }

            // Create partial applications for square and cube
            Func<double, double> square = value => Exponentiation(2, value); // Exponent 2 for square
            Func<double, double> cube = value => Exponentiation(3, value);   // Exponent 3 for cube

            // Initialize num1 and num2 with default values
            double num1 = 0, num2 = 0;

            // Get values from the form input
            if (double.TryParse(Request.Form["num1"], out num1) && double.TryParse(Request.Form["num2"], out num2))
            {
                // Check which button was clicked and calculate accordingly
                if (Request.Form["ADD"].Count > 0)
                {
                    // Perform summation
                    Summation = num1 + num2;
                    SquareResult = null; // Reset other results
                    CubeResult = null;
                }
                else if (Request.Form["SQUARE"].Count > 0)
                {
                    // Calculate square for num1
                    SquareResult = square(num1);
                    Summation = null; // Reset other results
                    CubeResult = null;
                }
                else if (Request.Form["CUBE"].Count > 0)
                {
                    // Calculate cube for num2
                    CubeResult = cube(num2);
                    Summation = null; // Reset other results
                    SquareResult = null;
                }
            }
            else
            {
                // Handle invalid input
                Summation = null;
                SquareResult = null;
                CubeResult = null;
            }
        }
    }
}
