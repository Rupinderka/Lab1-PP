﻿// For more information see https://aka.ms/fsharp-console-apps
printfn "Hello from F#"
let x = fun n -> n*n
let square = [2;3;4;5] |> List.map x
printfn "%A" square



let something = [4;5;6;7]
something |> List.iter (printfn "%A")
let newList = something |> List.collect (fun x -> [1..x])
printfn "%A" newList


let f = fun x->x%2 =0
let y = [4;5;6;7;8]
let res = y |> List.filter f
printfn "%A" res


// Tail-recursive function to find product of list elements
let rec productOfList list accumulator =
    match list with
    | [] -> accumulator
    | head :: tail -> productOfList tail (accumulator * head)

let numbers = [2; 3; 4; 5; 10]
let productResult = productOfList numbers 1
printfn "Product of list elements: %d" productResult

// Tail-recursive function for product of odd numbers
let rec productOfOdds n accumulator =
    if n <= 1 then accumulator
    else productOfOdds (n - 2) (accumulator * n)

let oddProductResult = productOfOdds 11 1
printfn "Product of all odd numbers from 11 to 1: %d" oddProductResult

// List of strings with extra spaces
let names = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]
let trimmedNames = names |> List.map (fun name -> name.Trim())

// Print trimmed names
trimmedNames |> List.iter (printfn "%s")

// Sequence of first 700 positive integers
let numbersList = [1..700]  // Renamed to 'numbersList' to avoid conflict

// Filter numbers that are multiples of both 7 and 5
let filteredNumbers = numbersList |> List.filter (fun n -> n % 7 = 0 && n % 5 = 0)

// Calculate the sum of the filtered numbers
let sum = filteredNumbers |> List.reduce (+)

// Print the result
printfn "Sum of filtered numbers: %d" sum

// List of strings
let namesList = ["James"; "Robert"; "John"; "William"; "Michael"; "David"; "Richard"]

// Filter names that contain the letter 'L' or 'l'
let filteredNames = namesList |> List.filter (fun name -> name.Contains("L") || name.Contains("l"))

// Concatenate the filtered names
let concatenatedNames = filteredNames |> List.reduce (+)

// Print the concatenated names
printfn "Concatenated names: %s" concatenatedNames

